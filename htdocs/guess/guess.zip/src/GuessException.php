<?php
/**
 * Exception class for GuessException.
 */
class GuessException extends Exception
{
}
